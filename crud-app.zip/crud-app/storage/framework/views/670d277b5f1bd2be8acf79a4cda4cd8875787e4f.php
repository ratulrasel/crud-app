<?php $__env->startSection('title'); ?>
    Manage page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="py-5 bg-light">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="card ">
                       <div class="card-header">All Student Info</div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <h4 class="text-center text-success"><?php echo e(Session::get('message')); ?></h4>
                                <table class="table table-hover table-bordered">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Mobile</th>
                                        <th>Address</th>
                                        <th>District Name</th>
                                        <th>Date of Birth</th>
                                        <th>Gender</th>
                                        <th>Subject</th>
                                        <th>Image</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($student->name); ?></td>
                                            <td><?php echo e($student->mobile); ?></td>
                                            <td><?php echo e($student->email); ?></td>
                                            <td><?php echo e($student->address); ?></td>
                                            <td><?php echo e($student->district_name); ?></td>
                                            <td><?php echo e($student->date_of_birth); ?></td>
                                            <td><?php echo e($student->gender); ?></td>
                                            <td><?php echo e($student->subject); ?></td>
                                            <td>
                                                <img src="<?php echo e(asset($student->image)); ?>" alt="" height="60px" width="90px">
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('student.edit', ['id' =>$student->id])); ?>" class="btn btn-primary btn-sm">
                                                    <i class="fa fa-edit"></i>
                                                </a>
                                                <a href="<?php echo e(route('student.delete', ['id' =>$student->id])); ?>" class="btn btn-danger btn-sm"onclick="return confirm('Are you sure to delete this..')">
                                                    <i class="fa fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crud-app\resources\views/student/manage.blade.php ENDPATH**/ ?>