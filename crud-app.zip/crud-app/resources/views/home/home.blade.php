@extends('master')

@section('title')
    Home page
@endsection

@section('content')
    <section class="py-5 bg-light">
        <div class="container">
            <div class="row">
                <div class="col-md-8 mx-auto">
                    <div class="card card-body">
                        <h1 class="text-center">This Is Home Page....</h1>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
