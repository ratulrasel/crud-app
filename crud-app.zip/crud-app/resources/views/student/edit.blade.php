@extends('master')

@section('title')
    Home page
@endsection
@section('content')
    <section class="py-5 bg-light">
        <div class="container">
            <div class="row">
                <div class="col-md-8 mx-auto">
                    <div class="card ">
                        <div class="card-header"><h4>Add Student Form</h4></div>
                        <div class="card-body">
                            <h4 class="text-success text-center">{{Session::get('message')}}</h4>
                            <form action="{{route('student.update',['id' =>$student->id])}}" method="POST" enctype="multipart/form-data">
                                @csrf
                                <div class="row mb-3">
                                    <label class="col-md-3">Name</label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" name="name" value="{{$student->name}}">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-md-3">Email</label>
                                    <div class="col-md-9">
                                        <input type="email" class="form-control" name="email" value="{{$student->email}}">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-md-3">Mobile</label>
                                    <div class="col-md-9">
                                        <input type="tel" class="form-control" name="mobile" value="{{$student->mobile}}">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-md-3">Address</label>
                                    <div class="col-md-9">
                                        <textarea class="form-control" name="address">{{$student->address}}</textarea>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-md-3">District Name</label>
                                    <div class="col-md-9">
                                        <select class="form-control" name="district_name">
                                            <option>--Select District Name--</option>
                                            <option value="Dhaka" {{$student->district_name=='Dhaka' ? 'selected' : ''}}>Dhaka</option>
                                            <option value="Bogra" {{$student->district_name=='Bogra' ? 'selected' : ''}}>Bogra</option>
                                            <option value="Rangpur" {{$student->district_name=='Rangpur' ? 'selected' : ''}}>Rangpur</option>
                                            <option value="Gaibandha" {{$student->district_name=='Gaibandha' ? 'selected' : ''}}>Gaibandha</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-md-3">Date Of Birth</label>
                                    <div class="col-md-9">
                                        <input type="date" class="form-control" name="date_of_birth" value="{{$student->date_of_birth}}">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-md-3">Gender</label>
                                    <div class="col-md-9">
                                        <label><input type="radio"  name="gender" {{$student->gender=='Male' ? 'checked' : ''}} value="Male"> Male</label>
                                        <label><input type="radio"  name="gender" {{$student->gender=='Female' ? 'checked' : ''}} value="Female"> Female</label>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-md-3">Image</label>
                                    <div class="col-md-9">
                                        <input type="file" class="form-control" name="image" >
                                        <img src="{{asset($student->image)}}" alt="" height="100" width="130">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-md-3">Subject Name</label>
                                    <div class="col-md-9">
                                        <label><input type="checkbox" name="subject[]" {{in_array('Bangla', $subjects) ? 'checked' : ''}} value="Bangla"> Bangla</label>
                                        <label><input type="checkbox" name="subject[]" {{in_array('English', $subjects) ? 'checked' : ''}} value="English"> English</label>
                                        <label><input type="checkbox" name="subject[]" {{in_array('Math', $subjects) ? 'checked' : ''}} value="Math"> Math</label>
                                        <label><input type="checkbox" name="subject[]" {{in_array('Physics', $subjects) ? 'checked' : ''}} value="Physics"> Physics</label>
                                        <label><input type="checkbox" name="subject[]" {{in_array('Chemistry', $subjects) ? 'checked' : ''}} value="Chemistry"> Chemistry</label>
                                        <label><input type="checkbox" name="subject[]" {{in_array('Biology', $subjects) ? 'checked' : ''}} value="Biology"> Biology</label>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-md-3"></label>
                                    <div class="col-md-9">
                                        <input type="submit" class="btn btn-success px-5"  value="Update Student Info">
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection


